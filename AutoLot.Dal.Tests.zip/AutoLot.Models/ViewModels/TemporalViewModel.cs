﻿namespace AutoLot.Models.ViewModels;
public class TemporalViewModel<T> where T : BaseEntity, new()
{
    public T Entity { get; set; }
    public DateTime ValidFrom { get; set; }
    public DateTime ValidTo { get; set; }
}