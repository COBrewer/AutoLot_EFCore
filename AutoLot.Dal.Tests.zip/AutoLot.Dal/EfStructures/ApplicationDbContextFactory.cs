﻿namespace AutoLot.Dal.EfStructures;
public class ApplicationDbContextFactory : IDesignTimeDbContextFactory<ApplicationDbContext>
{
    public ApplicationDbContext CreateDbContext(string[] args)
    {
        var optionsBuilder = new DbContextOptionsBuilder<ApplicationDbContext>();
        //var cs = @"Data Source=WLP-32TXBY3;Database=AutoLot_Hol;Integrated Security=True;Encrypt=False;Trust Server Certificate=True";
        var cs = @"Data Source=WLP-32TXBY3;Integrated Security=True;Encrypt=False;Trust Server Certificate=True";
        optionsBuilder.UseSqlServer(cs);
        optionsBuilder.ConfigureWarnings(cw => cw.Ignore(RelationalEventId.BoolWithDefaultWarning));
        Console.WriteLine(cs);
        return new ApplicationDbContext(optionsBuilder.Options);
    }
}
