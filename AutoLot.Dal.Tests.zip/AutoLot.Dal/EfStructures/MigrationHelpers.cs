﻿namespace AutoLot.Dal.EfStructures;
public static class MigrationHelpers
{
    //implementation goes here

    public static void CreateSproc(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.Sql(@"exec (N' 
 CREATE PROCEDURE [dbo].[GetPetName]
 @carID int, 
 @petName nvarchar(50) output
 AS
 SELECT @petName = PetName from dbo.Inventory where Id = @carID')"
        );
    }

    public static void DropSproc(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.Sql("EXEC (N' DROP PROCEDURE [dbo].[GetPetName]')");
    }

    public static void CreateFunctions(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.Sql(@"exec (N'
 CREATE FUNCTION [dbo].[udtf_GetCarsForMake] ( @makeId int )
 RETURNS TABLE 
 AS
 RETURN 
 (
 SELECT Id, IsDrivable, DateBuilt, Color, PetName, MakeId, TimeStamp, Display, Price
 FROM Inventory WHERE MakeId = @makeId
 )')"
        );
        migrationBuilder.Sql(@"exec (N'
 CREATE FUNCTION [dbo].[udf_CountOfMakes] ( @makeid int )
 RETURNS int
 AS
 BEGIN
 DECLARE @Result int
 SELECT @Result = COUNT(makeid) FROM dbo.Inventory WHERE makeid = @makeid
 RETURN @Result
 END')"
        );
    }

    public static void DropFunctions(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.Sql("EXEC (N' DROP FUNCTION [dbo].[udtf_GetCarsForMake]')");
        migrationBuilder.Sql("EXEC (N' DROP FUNCTION [dbo].[udf_CountOfMakes]')");
    }



}