﻿namespace AutoLot.Dal.Repos.Interfaces;
public interface IDriverRepo : IBaseRepo<Driver> { }
