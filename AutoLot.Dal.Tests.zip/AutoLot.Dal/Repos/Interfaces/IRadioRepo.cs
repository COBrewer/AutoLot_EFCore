﻿//IRadioRepo.cs
namespace AutoLot.Dal.Repos.Interfaces;
public interface IRadioRepo : ITemporalTableBaseRepo<Radio> { }