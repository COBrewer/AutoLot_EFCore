﻿//IMakeRepo.cs
namespace AutoLot.Dal.Repos.Interfaces;
public interface IMakeRepo : ITemporalTableBaseRepo<Make> { }
