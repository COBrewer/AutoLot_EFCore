﻿using System.Runtime.CompilerServices;
[assembly: InternalsVisibleTo("AutoLot.Dal.Tests")]